package A.VisualPlugin.Phone_001_714_463_5142;


import java.util.ArrayList;

public class Playlist extends ArrayList<SongInfo> {
	public Playlist() {
	}
	
	public Playlist(SongInfo p) {
		add(p);
	}
}