package A.VisualPlugin.Phone_001_714_463_5142;


public class SongInfo {
	public String songName, songUrl, artist, filePath;
	
	public SongInfo(String songName, String songUrl, String artist, String filePath) {
		this.songName = songName;
		this.songUrl = songUrl;
		this.artist = artist;
		this.filePath = filePath;
	}
}